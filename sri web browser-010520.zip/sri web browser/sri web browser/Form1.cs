﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Web;
namespace WindowsFormsApplication1
{
    public partial class back : Form
    {
        int ind = 0, y = 0;
        bool fullscreen=false;
        List<String> hist = new List<String>(1024);
        public back()
        {
            InitializeComponent();
            const string key = "HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION";

            try
            {
                Registry.SetValue(key, "Sri Web Browser.exe", 12000, RegistryValueKind.DWord);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            String url = textBox1.Text;
            if (url.StartsWith("file///"))
                url = url.Substring(7);
            else if (url.Contains("https://") != true && url.Contains("http://") != true)
            {
                if (url.StartsWith("www.")) url = "https://" + url;
                else if (url.Contains(".") && url.StartsWith(".") != true) url = "https://www." + url;
                else url = "https://www.ecosia.org/search?q=" + url;
            }
            Uri uri = new Uri(url);
            webBrowser1.Url = uri;

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            y = 0;
            progressBar1.Visible = false;
            String src = webBrowser1.DocumentText;
            try
            {
                this.Text = src.Substring(src.IndexOf("<title>") + 7, src.IndexOf("</title>") - src.IndexOf("<title>") - 7) + "-Sri Web Browser";
            }
            catch (Exception eee)
            {
                this.Text = "Sorry, title can't be found";
            }
            String currpage = webBrowser1.Url.OriginalString;
            textBox1.Text = currpage;
            hist.Add(currpage);
            ind++;
            if (ind == 1)
                backbutton.Enabled = true;
            try
            {
                System.IO.StreamWriter f1 = new System.IO.StreamWriter("D:\\history.txt", true);
                f1.WriteLine(DateTime.Now.ToString() + " " + currpage);
                f1.Close();
            }
            catch (Exception eee)
            {
                File.Create("D:\\history.txt");
                System.IO.StreamWriter f1 = new System.IO.StreamWriter("D:\\history.txt", true);
                f1.WriteLine(DateTime.Now.ToString() + " " + currpage);
                f1.Close();
            }
            textBox1.Focus();

        }
        private void back_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            webBrowser1.Url = new Uri("https://www.ecosia.org");
            textBox1.Text = "https://www.ecosia.org";
        }
        private void textBox1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                String url = textBox1.Text;
                if (url.StartsWith("file///"))
                    url = url.Substring(7);
                else if (url.Contains("https://") != true && url.Contains("http://") != true)
                {
                    if (url.StartsWith("www.")) url = "https://" + url;
                    else if (url.StartsWith("localhost")) url = "http://" + url;
                    else if (url.Contains(".") && url.StartsWith(".") != true) url = "https://www." + url;
                    else if (url.Contains(".google.com")) url = "https://" + url;
                    else url = "https://www.ecosia.org/search?q=" + url;
                }
                try
                {
                    hist.Add(url);
                    ind++;
                    Uri uri = new Uri(url);
                    webBrowser1.Url = uri;

                }
                catch (Exception ee)
                {
                    MessageBox.Show("Invalid url"); webBrowser1.Url = new Uri("http://www.ecosia.org");
                }

            }
            else if (e.KeyCode == Keys.F11)
            {
                textBox1.Focus();
                if (fullscreen == true)
                {
                    fullscreen = false;
                    webBrowser1.Location = new Point(3, 78);
                    groupBox1.Visible = true;
                    webBrowser1.Size = new Size(1299, 605);
                    this.FormBorderStyle = FormBorderStyle.Sizable;
                }
                else
                {
                    fullscreen = true;
                    groupBox1.Visible = false;
                    webBrowser1.Location = new Point(3, 0);
                    webBrowser1.Size = this.Size;
                    this.FormBorderStyle = FormBorderStyle.None;
                    MessageBox.Show("Press F11 to exit fullscreen mode.");
                }
            }
        }

        private void textBox1_DoubleClick(object sender, EventArgs e)
        {
            textBox1.SelectAll();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void frontbutton_Click(object sender, EventArgs e)
        {
           webBrowser1.GoForward();
        }

        private void go_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("cmd.exe", "/C D:\\history.txt");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sri Web Browser is a property of Sri Inc, Trichy. It was released on 9 Apr 2020. The purpose of this project is to make browsing super easy without any tracking.", "About Sri Web Browser");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("All your browsing data will be deleted. Is it OK?", "Clear History", MessageBoxButtons.OKCancel);
            if (res == DialogResult.OK)
            {
                System.IO.StreamWriter fw = new System.IO.StreamWriter("D:\\history.txt");
                fw.Write("");
                fw.Close();
                MessageBox.Show("All browsing history deleted successfully.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sri Web Browser is a very basic, easy-to-use and efficient browser. Special features:\n1. Easy typing of websites. google.com leads to google.\n2.URL Bar acts as an Ecosia Search Engine.\n3. Right Click and all necessary settings are here.\n4. To View Source, Ctrl+U or Right Click->View Source.\n5. F5 to refresh.\n6. To view history, click button or press Ctrl+H. To delete browsing history, Ctrl+Alt+H.\n7.To find, Ctrl+F\n8.To Print, Ctrl+P", "Help");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            back form2 = new back();
            form2.Show();
        }
        private void back_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                y += 20;
                webBrowser1.Document.Window.ScrollTo(0, y);
            }
            else if (e.KeyCode == Keys.Up)
            {
                y -= 20;
                if (y < 0 && y >= -20)
                    webBrowser1.Document.Window.ScrollTo(0, 0);
                else
                    webBrowser1.Document.Window.ScrollTo(0, y);
            }
            else if (e.KeyCode == Keys.F1)
                MessageBox.Show("Sri Web Browser is a very basic, easy-to-use and efficient browser. Special features:\n1. Easy typing of websites. google.com leads to google.\n2.URL Bar acts as an Ecosia Search Engine.\n3. Right Click and all necessary settings are here.\n4. To View Source, Ctrl+U or Right Click->View Source.\n5. F5 to refresh.\n6. To view history, click button or press Ctrl+H. To delete browsing history, Ctrl+Alt+H.\n7.To find, Ctrl+F\n8.To Print, Ctrl+P", "Help");
            else if (e.Control.Equals(true) && e.KeyCode == Keys.U)
            {
                StreamWriter sw = new StreamWriter("D:\\html.txt");
                sw.Write(webBrowser1.DocumentText);
                sw.Close();
                System.Diagnostics.Process.Start("notepad.exe", "D:\\html.txt");
            }
            else if (e.Shift.Equals(false) && e.Control.Equals(true) && e.KeyCode == Keys.H)
                System.Diagnostics.Process.Start("D:\\history.txt");
            else if (e.Shift.Equals(true) && e.Control.Equals(true) && e.KeyCode == Keys.H)
            {
                DialogResult res = MessageBox.Show("All your browsing data will be deleted. Is it OK?", "Clear History", MessageBoxButtons.OKCancel);
                if (res == DialogResult.OK)
                {
                    System.IO.StreamWriter fw = new System.IO.StreamWriter("D:\\history.txt");
                    fw.Write("");
                    fw.Close();
                    MessageBox.Show("All browsing history deleted successfully.");
                }
            }
            else if (e.Control.Equals(true) && e.KeyCode == Keys.N)
                new back().Show();
            else if (e.KeyCode == Keys.F11)
            {
                textBox1.Focus();
                if (fullscreen == true)
                {
                    fullscreen = false;
                    webBrowser1.Location = new Point(3, 78);
                    groupBox1.Visible = true;
                    webBrowser1.Size=new Size(1299,605);
                    this.FormBorderStyle = FormBorderStyle.Sizable;
                }
                else
                {
                    fullscreen = true;
                    groupBox1.Visible = false;
                    webBrowser1.Location = new Point(3,0);
                    webBrowser1.Size = this.Size;
                    this.FormBorderStyle = FormBorderStyle.None;
                    MessageBox.Show("Press F11 to exit fullscreen mode.");
                }
            }
        }
        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            y = webBrowser1.Document.Window.Position.Y;
        }

        private void back_KeyUp(object sender, KeyEventArgs e)
        {
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways=true;
            t.SetToolTip(button4, "Clears history (Ctrl+Alt+H)");
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button5, "Click to remove text from address bar.");
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button3, "Loads the URL/Refresh (F5)");
        }

        private void go_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(go, "Shows browsing history (Ctrl+H)");
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button1, "Help (F1)");
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button2, "Displays information about the browser.");
        }

        private void backbutton_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(backbutton, "Loads previous webpage.");
        }

        private void frontbutton_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(frontbutton, "Loads next webpage.");
        }

        private void button6_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button6, "Opens new window.");
        }

        private void textBox1_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(textBox1, "Address bar. Type url in any format. If no http, www or .com, it acts as an Ecosia Search Bar.");
        }

        private void button7_Click(object sender, EventArgs e)
        {
                fullscreen = true;
                textBox1.Focus();
                groupBox1.Visible = false;
                webBrowser1.Location = new Point(3, 0);
                webBrowser1.Size = this.Size;
                this.FormBorderStyle = FormBorderStyle.None;
                MessageBox.Show("Press F11 to exit fullscreen mode.");
        }

        private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            
        }

        private void webBrowser1_RegionChanged(object sender, EventArgs e)
        {
                MessageBox.Show(e.ToString());
        }


        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please press Ctrl+F.");
        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            progressBar1.Visible = true;
            for (int i = 0; i < 100; i++)
            {
                progressBar1.Value = i;
                System.Threading.Thread.Sleep(10);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            System.IO.StreamReader sr = new System.IO.StreamReader("D:\\history.txt");
            String[] viewed = sr.ReadToEnd().Split('\n');
            sr.Close();
            String[] last = viewed[viewed.Length - 2].Split(' ');
            webBrowser1.Url = new Uri(last[3]);
        }

        private void button8_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways = true;
            t.SetToolTip(button8, "Use Ctrl+F to search in webpage.");
        }

        private void button9_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.ShowAlways=true;
            t.SetToolTip(button9,"Click here to view the page you last browsed.");
        }

        private void webBrowser1_ClientSizeChanged(object sender, EventArgs e)
        {
            webBrowser1.Size = ClientSize;
        }
    }
}
